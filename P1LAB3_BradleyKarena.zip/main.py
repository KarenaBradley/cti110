''' Type your code here. '''

print('Hello World!')