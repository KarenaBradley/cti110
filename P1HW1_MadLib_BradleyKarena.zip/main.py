''' Type your code here. '''


print('Eric', 'went to', 'Chipotle', 'to buy', '12', 'different types of', 'cars')